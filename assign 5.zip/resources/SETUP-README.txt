#Setup for the application


1) Creating a Portfolio with 3 or 2 stocks:
    - Select option 1 (CreatePortFolio)
    - Enter the portfolio name
    - Enter the tickernames and number of units as per the guidelines in readme.
    - After adding all the stocks, this portfolio will be saved in the system in a .csv file

2) Query the value for a portfolio:
    - Select Option 3
    - Select the portfolio for which you wish to calculate the value.
    - Enter the date for value calculation.